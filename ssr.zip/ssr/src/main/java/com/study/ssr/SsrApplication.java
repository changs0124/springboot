package com.study.ssr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsrApplication.class, args);
	}

}
