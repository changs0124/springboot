package com.study.ssr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsrApplicationTests {

	@Test
	void contextLoads() {
	}

}
